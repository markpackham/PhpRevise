-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2018 at 11:59 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeig`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `name`, `created_at`) VALUES
(1, 1, 'Business', '2018-02-19 10:35:25'),
(2, 1, 'Technology', '2018-02-19 10:35:25'),
(3, 2, 'Yu-Gi-Oh', '2018-02-19 15:17:58');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `name`, `email`, `body`, `created_at`) VALUES
(1, 9, 'Timmy', 'timmy@hotmail.com', 'This is a comments test', '2018-02-20 09:56:21'),
(2, 9, 'Mr Comment Test', 'commenttest@hotmail.com', 'This is another comment test', '2018-02-20 10:06:56');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `body`, `post_image`, `created_at`) VALUES
(8, 1, 1, 'image test', 'image-test', '<p>fsd</p>\r\n', 'OS_Ubuntu.png', '2018-02-19 11:45:26'),
(9, 3, 1, 'No Image Blog Post', 'No-Image-Blog-Post', '<p>No images can be seen from here</p>\r\n', 'noimage.jpg', '2018-02-19 15:46:14'),
(10, 2, 1, 'Another post from admin', 'Another-post-from-admin', '<p>admin posted this</p>\r\n', 'angular.png', '2018-02-20 15:52:06'),
(11, 3, 2, 'admin2\'s first post', 'admin2s-first-post', '<p>admin2 whose password is admin2 posted this</p>\r\n', 'codeigniter.jpg', '2018-02-20 15:53:19'),
(12, 1, 1, 'Lion El\'Jonson', 'Lion-ElJonson', '<p><a href=\"http://warhammer40k.wikia.com/wiki/Dark_Angels\">Dark Angels</a></p>\r\n', 'noimage.jpg', '2018-02-20 18:59:32'),
(13, 1, 1, 'Fulgrim', 'Fulgrim', '<p><a href=\"http://warhammer40k.wikia.com/wiki/Emperor%27s_Children\">Emperor&#39;s Children</a></p>\r\n', 'noimage.jpg', '2018-02-20 19:00:00'),
(14, 1, 1, 'Perturabo', 'Perturabo', '<p><a href=\"http://warhammer40k.wikia.com/wiki/Iron_Warriors\">Iron Warriors</a></p>\r\n', 'noimage.jpg', '2018-02-20 19:00:39'),
(15, 1, 1, 'Jaghatai Khan', 'Jaghatai-Khan', '<p><a href=\"http://warhammer40k.wikia.com/wiki/White_Scars\">White Scars</a></p>\r\n', 'noimage.jpg', '2018-02-20 19:00:54'),
(16, 1, 1, 'Sanguinius', 'Sanguinius', '<p><a href=\"http://warhammer40k.wikia.com/wiki/Blood_Angels\">Blood Angels</a> are the best thanks to their Primarch</p>\r\n', 'noimage.jpg', '2018-02-20 19:02:11'),
(17, 1, 1, 'Leman Russ', 'Leman-Russ', '<p>Space Wolves</p>\r\n', 'noimage.jpg', '2018-02-21 06:45:10'),
(18, 1, 1, 'Rogal Dorn', 'Rogal-Dorn', '<p>Imperial Fists</p>\r\n', 'noimage.jpg', '2018-02-21 06:50:45'),
(19, 1, 1, 'Konrad Curze', 'Konrad-Curze', '<p>Night Lords</p>\r\n', 'noimage.jpg', '2018-02-21 06:59:54'),
(20, 1, 1, 'Ferrus Manus', 'Ferrus-Manus', '<p>Iron Hands</p>\r\n', 'noimage.jpg', '2018-02-21 07:16:53'),
(21, 1, 1, 'Angron', 'Angron', '<p>World Eaters</p>\r\n', 'noimage.jpg', '2018-02-21 07:20:33'),
(22, 1, 1, 'Roboute Guilliman', 'Roboute-Guilliman', '<p>Ultramarines</p>\r\n', 'noimage.jpg', '2018-02-21 07:22:34'),
(23, 1, 1, 'Mortarion', 'Mortarion', '<p>Death Guard</p>\r\n', 'noimage.jpg', '2018-02-21 10:52:53'),
(24, 1, 1, 'Magnus the Red', 'Magnus-the-Red', '<p>Thousand Sons</p>\r\n', 'noimage.jpg', '2018-02-21 10:57:51'),
(25, 1, 1, 'Horus Lupercal', 'Horus-Lupercal', '<p>Luna Wolves/Sons of Horus</p>\r\n', 'noimage.jpg', '2018-02-21 10:58:33');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'admin', '', 'admin@hotmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2018-02-20 11:20:59'),
(2, 'admin2', '', 'admin2@hotmail.com', 'admin2', 'c84258e9c39059a89ab77d846ddab909', '2018-02-20 15:52:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
